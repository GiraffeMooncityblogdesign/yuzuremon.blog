tinyMCE.addI18n(tinymce.settings.language + '.mt_insert_html', {
    title: trans('Insert HTML'),
    source: trans('Source')
});
