tinyMCE.addI18n(tinyMCE.settings.language + '.template_dlg', {
    title: trans('Boilerplate'),
    label: trans('Name'),
    'desc_label': trans('Description'),
    desc: trans('Insert Boilerplate'),
    select: trans('Select Boilerplate'),
    preview: trans('Preview'),
});
