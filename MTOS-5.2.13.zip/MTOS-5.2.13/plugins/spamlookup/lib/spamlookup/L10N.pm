# Movable Type (r) Open Source (C) 2006-2013 Six Apart, Ltd.
# This program is distributed under the terms of the
# GNU General Public License, version 2.
#
# $Id$

# Original copyright (c) 2004-2006, Brad Choate and Tobias Hoellrich

package spamlookup::L10N;
use strict;

use MT::Plugin::L10N;
@spamlookup::L10N::ISA = qw(MT::Plugin::L10N);

1;
