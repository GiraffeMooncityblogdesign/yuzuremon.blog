package spamlookup::L10N::en_us;

use strict;

use base 'spamlookup::L10N';
use vars qw( %Lexicon );
%Lexicon = ();

1;
